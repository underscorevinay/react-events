// Skeleton placeholder shown while events are loading

import { Box, Skeleton, SkeletonText } from "@chakra-ui/react";

export const EventSkeleton = () => {
  return (
    <Box borderWidth="1px" borderRadius="lg" p={4}>
      <Skeleton height="160px" mb={4} />
      <SkeletonText noOfLines={2} />
    </Box>
  );
};
