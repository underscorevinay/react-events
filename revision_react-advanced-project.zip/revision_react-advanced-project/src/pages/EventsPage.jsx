// This page displays a list of all events.
// It includes search, category filtering, and loading skeletons.

import { useContext, useState } from "react";
import { EventContext } from "../components/context/EventContext";
import {
  Box,
  Heading,
  Input,
  SimpleGrid,
  Stack,
  Checkbox,
} from "@chakra-ui/react";
import { EventCard } from "../components/events/EventCard";
import { EventSkeleton } from "../components/events/EventSkeleton";

export const EventsPage = () => {
  // Events, categories and loading state are provided via Context
  const { events, categories, users, loading } =
    useContext(EventContext);

  const [search, setSearch] = useState("");

  // Selected categories for filtering (multiple selection required)
  const [selectedCategories, setSelectedCategories] = useState([]);

  // Filter events based on search text and selected categories
  const filteredEvents = events.filter((event) => {
    const matchesSearch = event.title
      .toLowerCase()
      .includes(search.toLowerCase());

    const matchesCategory =
      selectedCategories.length === 0 ||
      selectedCategories.some((categoryId) =>
        event.categoryIds.includes(categoryId)
      );

    return matchesSearch && matchesCategory;
  });

  return (
    <Box p={6}>
      <Heading mb={4}>Events</Heading>

      {/* Search input */}
      <Input
        placeholder="Search events..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        mb={4}
        required
      />

      {/* Category filter */}
      {/* ChatGPT help: Chakra UI v3 uses Checkbox.Root instead of the old Checkbox */}
<Stack direction="row" mb={6} wrap="wrap" gap={4}>
  {categories.map((cat) => (
    <Checkbox.Root
      key={cat.id}
      checked={selectedCategories.includes(cat.id)}
      onCheckedChange={(details) => {
        const isChecked = details.checked === true;

        setSelectedCategories((prev) =>
          isChecked
            ? [...prev, cat.id]
            : prev.filter((id) => id !== cat.id)
        );
      }}
    >
      {/* ChatGPT help: REQUIRED in Chakra v3 – otherwise checkbox is not clickable */}
      <Checkbox.HiddenInput />

      <Checkbox.Control />
      <Checkbox.Label>{cat.name}</Checkbox.Label>
    </Checkbox.Root>
  ))}
</Stack>


      {/* Events list or skeletons while loading */}
      <SimpleGrid columns={[1, 2, 3]} gap={6}>
        {loading
          ? Array.from({ length: 6 }).map((_, index) => (
              <EventSkeleton key={index} />
            ))
          : filteredEvents.map((event) => (
              <EventCard
                key={event.id}
                event={event}
                categories={categories}
                users={users}
              />
            ))}
      </SimpleGrid>
    </Box>
  );
};
