// AboutPage.jsx
// Mandatory third page

import { Box, Heading, Text } from "@chakra-ui/react";

export const AboutPage = () => (
  <Box p={6}>
    <Heading>About</Heading>
    <Text mt={4}>An online academy turned to an event organiser, doing so with a winc.
      This page is currently under construction.
      
      Reach out to us via: learneradmin@wincacademy.nl</Text>
  </Box>
);
