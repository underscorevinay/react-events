import { useContext, useState } from "react";
import {
  Button,
  Input,
  Textarea,
  Stack,
  Checkbox,
  Dialog,
} from "@chakra-ui/react";
import { EventContext } from "../context/EventContext";

export const AddEventModal = () => {
  const { addEvent, categories } = useContext(EventContext);

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [image, setImage] = useState("");
  const [location, setLocation] = useState("");
  const [startTime, setStartTime] = useState("");
  const [endTime, setEndTime] = useState("");
  const [selectedCategories, setSelectedCategories] = useState([]);

  const toggleCategory = (id) => {
    setSelectedCategories((prev) =>
      prev.includes(id)
        ? prev.filter((c) => c !== id)
        : [...prev, id]
    );
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    await addEvent({
      title,
      description,
      image,
      location,
      startTime,
      endTime,
      categoryIds: selectedCategories,
      createdBy: 1,
    });

    setTitle("");
    setDescription("");
    setImage("");
    setLocation("");
    setStartTime("");
    setEndTime("");
    setSelectedCategories([]);
  };

  return (
    <Dialog.Root>
      <Dialog.Trigger asChild>
        <Button>Add Event</Button>
      </Dialog.Trigger>

      <Dialog.Backdrop />
      <Dialog.Positioner>
        <Dialog.Content>
          <Dialog.Header>Add Event</Dialog.Header>

          <form onSubmit={handleSubmit}>
            <Dialog.Body>
              <Stack spacing={3}>
                <Input value={title} onChange={(e) => setTitle(e.target.value)} required />
                <Textarea value={description} onChange={(e) => setDescription(e.target.value)} required />
                <Input value={image} onChange={(e) => setImage(e.target.value)} required />
                <Input value={location} onChange={(e) => setLocation(e.target.value)} required />
                <Input type="datetime-local" value={startTime} onChange={(e) => setStartTime(e.target.value)} required />
                <Input type="datetime-local" value={endTime} onChange={(e) => setEndTime(e.target.value)} required />

                {categories.map((cat) => (
                  <Checkbox.Root
                    key={cat.id}
                    checked={selectedCategories.includes(cat.id)}
                    onCheckedChange={() => toggleCategory(cat.id)}
                  >
                    <Checkbox.Control />
                    <Checkbox.Label>{cat.name}</Checkbox.Label>
                  </Checkbox.Root>
                ))}
              </Stack>
            </Dialog.Body>

            <Dialog.Footer>
              <Button type="submit">Save Event</Button>
            </Dialog.Footer>
          </form>
        </Dialog.Content>
      </Dialog.Positioner>
    </Dialog.Root>
  );
};
