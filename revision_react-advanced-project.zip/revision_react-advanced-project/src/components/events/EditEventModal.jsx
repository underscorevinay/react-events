// Modal with form to edit an existing event, wasn't working correctly before revision.

import { useContext, useState } from "react";
import {
  Button,
  Input,
  Textarea,
  Dialog,
  Flex,
} from "@chakra-ui/react";
import { EventContext } from "../context/EventContext";

export const EditEventModal = ({ event }) => {
  const { updateEvent } = useContext(EventContext);

  // Local form state for editing
  const [title, setTitle] = useState(event.title);
  const [description, setDescription] = useState(event.description);

  const handleSubmit = async (e) => {
    e.preventDefault();

    await updateEvent(event.id, {
      ...event,
      title,
      description,
    });
  };

  return (
    <Dialog.Root>
      <Dialog.Trigger asChild>
        <Button>Edit Event</Button>
      </Dialog.Trigger>

      <Dialog.Backdrop />
      <Dialog.Positioner>
        <Dialog.Content>
          <Dialog.Header>Edit Event</Dialog.Header>

          <form onSubmit={handleSubmit}>
            <Dialog.Body>
              <Flex direction="column" gap={3}>
                <Input
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  required
                />

                <Textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  required
                />
              </Flex>
            </Dialog.Body>

            <Dialog.Footer>
              <Button type="submit">Save changes</Button>
            </Dialog.Footer>
          </form>
        </Dialog.Content>
      </Dialog.Positioner>
    </Dialog.Root>
  );
};
