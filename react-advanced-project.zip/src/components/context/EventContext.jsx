import { createContext, useEffect, useState } from "react";
import { toaster } from "../ui/toaster";

export const EventContext = createContext({});

export const EventProvider = ({ children }) => {
  const [events, setEvents] = useState([]);
  const [categories, setCategories] = useState([]);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(false);

  // Fetch all backend data
  const fetchData = async () => {
    setLoading(true);

    try {
      const [eventsRes, categoriesRes, usersRes] = await Promise.all([
        fetch("http://localhost:3000/events"),
        fetch("http://localhost:3000/categories"),
        fetch("http://localhost:3000/users"),
      ]);

      setEvents(await eventsRes.json());
      setCategories(await categoriesRes.json());
      setUsers(await usersRes.json());
    } catch {
      // No unused error variable > no ESLint warning
      toaster.create({
        title: "Error",
        description: "Failed to load data",
        type: "error",
      });
    } finally {
      setLoading(false);
    }
  };

  const addEvent = async (event) => {
    try {
      await fetch("http://localhost:3000/events", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(event),
      });

      toaster.create({
        title: "Success",
        description: "Event created",
        type: "success",
      });

      fetchData();
    } catch {
      toaster.create({
        title: "Error",
        description: "Failed to create event",
        type: "error",
      });
    }
  };

  const updateEvent = async (id, event) => {
    try {
      await fetch(`http://localhost:3000/events/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(event),
      });

      toaster.create({
        title: "Success",
        description: "Event updated",
        type: "success",
      });

      fetchData();
    } catch {
      toaster.create({
        title: "Error",
        description: "Failed to update event",
        type: "error",
      });
    }
  };

  const deleteEvent = async (id) => {
    try {
      const response = await fetch(
        `http://localhost:3000/events/${id}`,
        { method: "DELETE" }
      );

      if (!response.ok) {
        throw new Error();
      }

      toaster.create({
        title: "Success",
        description: "Event deleted",
        type: "success",
      });

      fetchData();
    } catch {
      toaster.create({
        title: "Error",
        description: "Failed to delete event",
        type: "error",
      });
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  return (
    <EventContext.Provider
      value={{
        events,
        categories,
        users,
        loading,
        addEvent,
        updateEvent,
        deleteEvent,
      }}
    >
      {children}
    </EventContext.Provider>
  );
};
