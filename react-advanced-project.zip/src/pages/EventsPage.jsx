// Have to create the following functions: search, filters and loading skeletons

import { useContext, useState } from "react";
import { EventContext } from "../components/context/EventContext";
import {
  Box,
  Heading,
  Input,
  SimpleGrid,
  Stack,
  Checkbox,
} from "@chakra-ui/react";
import { EventCard } from "../components/events/EventCard";
import { EventSkeleton } from "../components/events/EventSkeleton";

export const EventsPage = () => {
  const { events, categories, users, loading } =
    useContext(EventContext);

  const [search, setSearch] = useState("");
  const [selectedCategories, setSelectedCategories] = useState([]);

  // Filter events based on search input and selected categories
  const filteredEvents = events.filter((event) => {
    const matchesSearch = event.title
      .toLowerCase()
      .includes(search.toLowerCase());

    const matchesCategory =
      selectedCategories.length === 0 ||
      selectedCategories.some((categoryId) =>
        event.categoryIds.includes(categoryId)
      );

    return matchesSearch && matchesCategory;
  });

  return (
    <Box p={6}>
      <Heading mb={4}>Events</Heading>

      {/* Search input */}
      <Input
        placeholder="Search events..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        mb={4}
        required
      />

      {/* Category filter checkboxes (Chakra UI v3) */}
      <Stack direction="row" mb={6}>
        {categories.map((cat) => (
          <Checkbox.Root
            key={cat.id}
            checked={selectedCategories.includes(cat.id)}
            onCheckedChange={(details) => {
              if (details.checked) {
                setSelectedCategories((prev) => [...prev, cat.id]);
              } else {
                setSelectedCategories((prev) =>
                  prev.filter((id) => id !== cat.id)
                );
              }
            }}
          >
            <Checkbox.Control />
            <Checkbox.Label>{cat.name}</Checkbox.Label>
          </Checkbox.Root>
        ))}
      </Stack>

      {/* Events list or loading skeletons */}
      <SimpleGrid columns={[1, 2, 3]} gap={6}>
        {loading
          ? Array.from({ length: 6 }).map((_, index) => (
              <EventSkeleton key={index} />
            ))
          : filteredEvents.map((event) => (
              <EventCard
                key={event.id}
                event={event}
                categories={categories}
                users={users}
              />
            ))}
      </SimpleGrid>
    </Box>
  );
};
