// Shows full event details and allows editing + deleting. The latter part just added in the revision.

import { useParams, useNavigate } from "react-router-dom";
import { useContext } from "react";
import { EventContext } from "../components/context/EventContext";
import { Box, Heading, Text, Image, Button, Flex } from "@chakra-ui/react";
import { EditEventModal } from "../components/events/EditEventModal";

export const EventPage = () => {
  const { eventId } = useParams();
  const navigate = useNavigate();
  const { events, categories, users, deleteEvent } =
    useContext(EventContext);

  const event = events.find((e) => e.id === Number(eventId));
  if (!event) return null;

  const categoryNames = categories
    .filter((cat) => event.categoryIds.includes(cat.id))
    .map((cat) => cat.name)
    .join(", ");

  const creator = users.find(
    (user) => user.id === event.createdBy
  );

  return (
    <Box p={6}>
      <Heading mb={4}>{event.title}</Heading>

      <Image src={event.image} mb={4} />

      <Text mb={2}>{event.description}</Text>
      <Text>Location: {event.location}</Text>
      <Text>
        Time:{" "}
        {new Date(event.startTime).toLocaleString()} –{" "}
        {new Date(event.endTime).toLocaleString()}
      </Text>
      <Text>Categories: {categoryNames}</Text>
      {creator && <Text>Created by: {creator.name}</Text>}

      {/* Edit + delete actions required by Winc */}
      <Flex gap={4} mt={6}>
        <EditEventModal event={event} />

        <Button
          colorPalette="red"
          onClick={async () => {
            if (window.confirm("Are you sure you want to delete this event?")) {
              await deleteEvent(event.id);
              navigate("/");
            }
          }}
        >
          Delete event
        </Button>
      </Flex>
    </Box>
  );
};
