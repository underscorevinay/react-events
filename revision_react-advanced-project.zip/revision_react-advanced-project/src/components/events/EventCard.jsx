// Clickable card that links to the single Event page

import { Box, Heading, Text, Image } from "@chakra-ui/react";
import { Link } from "react-router-dom";

export const EventCard = ({ event, categories }) => {
  const categoryNames = categories
    .filter((cat) => event.categoryIds.includes(cat.id))
    .map((cat) => cat.name)
    .join(", ");

  return (
    <Box
      borderWidth="1px"
      borderRadius="lg"
      p={4}
      as={Link}
      to={`/event/${event.id}`}
    >
      <Image src={event.image} mb={3} />
      <Heading size="md">{event.title}</Heading>
      <Text>{event.description}</Text>
      <Text fontSize="sm">Categories: {categoryNames}</Text>
    </Box>
  );
};
