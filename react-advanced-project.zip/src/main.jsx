// Commands I ran in the terminal, even a Chakra command to --hopefully-- troubleshoot an issue 
// npm install 
// npm audit
// npm install @reduxjs/toolkit react-redux 
// npm init @eslint/config@latest 
// npm install @chakra-ui/react @emotion/react @emotion/styled @chakra-ui/cli 
// npx @chakra-ui/cli snippet add 
// npm i -g json-server@0.17.4

// json-server --watch events.json
// npm run dev



// main.jsx
// Wrapping both with Chakra and Event


import React from "react";
import ReactDOM from "react-dom/client";
import { Provider } from "./components/ui/provider";
import { EventProvider } from "./components/context/EventContext";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import { Root } from "./components/Root";
import { EventsPage } from "./pages/EventsPage";
import { EventPage } from "./pages/EventPage";
import { AboutPage } from "./pages/AboutPage";

const router = createBrowserRouter([
  {
    path: "/",
    element: <Root />,
    children: [
      { path: "/", element: <EventsPage /> },
      { path: "/event/:eventId", element: <EventPage /> },
      { path: "/about", element: <AboutPage /> },
    ],
  },
]);

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <Provider>
      <EventProvider>
        <RouterProvider router={router} />
      </EventProvider>
    </Provider>
  </React.StrictMode>
);
