import { Flex, Button } from "@chakra-ui/react";
import { Link as RouterLink } from "react-router-dom";
import { AddEventModal } from "./events/AddEventModal";

export const Navigation = () => {
  return (
    <Flex gap={4} p={4}>
      {/* React Router navigation */}
      <Button as={RouterLink} to="/">
        Events
      </Button>

      <Button as={RouterLink} to="/about">
        About
      </Button>

      {/* Add Event via modal */}
      <AddEventModal />
    </Flex>
  );
};
