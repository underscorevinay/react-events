import {
  Box,
  Heading,
  Text,
  Image,
} from "@chakra-ui/react";
import { Link } from "react-router-dom";

export const EventCard = ({ event, categories, users }) => {
  const categoryNames = categories
    .filter((cat) => event.categoryIds.includes(cat.id))
    .map((cat) => cat.name)
    .join(", ");

  const creator = users.find(
    (user) => user.id === event.createdBy
  );

  return (
    <Box
      as={Link}
      to={`/event/${event.id}`}
      borderWidth="1px"
      borderRadius="lg"
      p={4}
    >
      <Image src={event.image} alt={event.title} mb={3} />

      <Heading size="md">{event.title}</Heading>
      <Text>{event.description}</Text>

      <Text fontSize="sm">
        📍 {event.location}
      </Text>

      <Text fontSize="sm">
        🕒 {new Date(event.startTime).toLocaleString()} –{" "}
        {new Date(event.endTime).toLocaleString()}
      </Text>

      <Text fontSize="sm">
        Categories: {categoryNames}
      </Text>

      {creator && (
        <Text fontSize="xs">
          Created by: {creator.name}
        </Text>
      )}
    </Box>
  );
};
